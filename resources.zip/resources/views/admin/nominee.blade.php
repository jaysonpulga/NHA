@extends('layouts.main')
@section('content')



<section class="content-header">
  <h1>
	<i class="fa fa-gears"></i> Nominee
  </h1>
</section>

<div style="margin-top:20px;margin-bottom:20px"></div>

<!-- Main content -->
<section class="content">
<!-- Main row -->
<div class="row">
	<div class="col-lg-12">

	
	
			
			
	</div>	  
</div>
<!-- /.row (main row) -->
</section>
<!-- /.content -->





@endsection

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Overview_campaign_group extends Model
{
    //
}

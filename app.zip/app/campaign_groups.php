<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class campaign_groups extends Model
{
    //
}
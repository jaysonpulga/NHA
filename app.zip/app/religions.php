<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class religions extends Model
{
    //
}

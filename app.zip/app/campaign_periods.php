<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class campaign_periods extends Model
{
    //
}

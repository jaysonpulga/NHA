<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class campaign_tally_periods extends Model
{
    //
}

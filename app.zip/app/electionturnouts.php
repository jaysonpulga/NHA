<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class electionturnouts extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class campaign_group_members extends Model
{
    //
}
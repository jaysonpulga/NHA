<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class overview_campaign_group_members extends Model
{
    //
}
